# The Mind Behind the Click

An independent digital journalism and consumer psychology publication by **Dharshini T**.

## Run locally
1. Download and extract the ZIP.
2. Open `index.html` in a modern browser.
3. For a more realistic local server, open the folder in VS Code and use the Live Server extension.

## Publish with GitHub Pages
1. Create a GitHub repository, for example `the-mind-behind-the-click`.
2. Upload all files and folders in this project to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. Your public URL will appear in the Pages settings.

## Project structure
- `index.html` — homepage and site shell
- `styles.css` — visual system, responsive layouts and animated background
- `script.js` — chapter data, article pages, search and bookmarks
- `robots.txt` — crawler guidance
- `sitemap.xml` — starter sitemap (update the domain after publishing)

## Current functionality
- Five chapter landing pages generated from structured content
- Four introductory investigations
- Research-library glossary
- Search across chapters, articles and concepts
- Browser-local article bookmarks
- Share article action (uses native share where supported)
- Responsive navigation
- Animated cosmic atmosphere with reduced-motion support

## Important editorial note
The current articles are introductory editorial explainers. They are not presented as completed empirical investigations or systematic literature reviews. Add verified sources, publication details, citations and methodology before treating them as fully researched journalism. The Consumer Files section is explicitly awaiting real research data. No fake survey results are included.

## Before publishing
- Replace the starter sitemap URL with your real GitHub Pages domain.
- Add a contact email and real social links if you want them displayed.
- Verify every factual claim and add source links.
- Test the site on mobile and desktop.
- Consider adding a backend or trusted form provider before collecting survey responses or newsletter subscriptions.
