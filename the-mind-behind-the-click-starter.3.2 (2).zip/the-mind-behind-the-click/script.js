const chapters = [
 {id:"buying-mind",n:"01",title:"The Buying Mind",question:"What happens inside the human mind before a purchase?",desc:"A closer look at desire, value, trust and the many small judgements that shape what ends up in our basket.",topics:["Why We Buy What We Buy","Emotional vs Rational Buying","Impulse Buying Psychology","Brand Loyalty & Attachment","Luxury Consumption","Price Perception","The Power of Discounts","Consumer Trust","Decision Fatigue","Online Shopping Psychology","Packaging & Perception","Familiarity and Brand Choice"]},
 {id:"influence-factor",n:"02",title:"The Influence Factor",question:"How do other people shape what we think, trust and purchase?",desc:"From creators and customer reviews to online communities, explore the social forces that guide consumer decisions.",topics:["Influencer Marketing","Online Reviews & Trust","Social Proof","Celebrity Endorsements","Parasocial Relationships","User-Generated Content","Word of Mouth","Followers, Likes & Signals","Micro vs Macro Influencers","Online Communities","Authenticity in Advertising","Viral Recommendations"]},
 {id:"psychology-persuasion",n:"03",title:"The Psychology of Persuasion",question:"How do brands influence decisions through messages and experiences?",desc:"Understand persuasive design, behavioural principles and the ethical line between helping people choose and manipulating them.",topics:["Fear of Missing Out","Scarcity Marketing","Urgency & Countdown Design","Colour in Advertising","Emotional Storytelling","Headline Psychology","Persuasive Copywriting","Reciprocity","Anchoring Effect","Loss Aversion","Framing Effect","Choice Architecture","Neuromarketing Fundamentals","Call-to-Action Psychology"]},
 {id:"digital-consumer",n:"04",title:"The Digital Consumer",question:"What is the internet doing to our attention, habits and decisions?",desc:"Investigate the platforms, interfaces and digital habits that shape modern consumer culture.",topics:["Why We Keep Scrolling","Infinite Scroll Design","The Attention Economy","Recommendation Algorithms","Dopamine & Digital Habits","Social Media Use & Wellbeing","Digital Distractions","Viral Trends","Online Identity","Digital Consumer Culture","Notification Psychology","Short-Form Video","Personalisation","AI & Consumer Psychology"]},
 {id:"consumer-files",n:"05",title:"The Consumer Files",question:"What can original research reveal about real consumer choices?",desc:"The publication's field desk for surveys, interviews and transparent student-led research.",topics:["Gen Z Brand Trust Study","Student Shopping Habits","Influencer Credibility Survey","Online Advertising Trust","Brand Discovery Behaviour","Digital Marketing Awareness"]}
];
const concepts = [
 ["Anchoring Effect","A first number or reference point can shape how later information is judged.","DECISION-MAKING"],
 ["Social Proof","People may look to others' choices when deciding what is appropriate or trustworthy.","INFLUENCE"],
 ["Loss Aversion","In some decisions, a potential loss can weigh more heavily than an equivalent gain.","BEHAVIOURAL ECONOMICS"],
 ["Mere Exposure","Repeated exposure can increase familiarity and, in some contexts, liking.","PERCEPTION"],
 ["Cognitive Dissonance","The discomfort that can arise when beliefs, actions or new information conflict.","DECISION-MAKING"],
 ["Scarcity Principle","Limited availability can increase perceived urgency or desirability.","PERSUASION"],
 ["Framing Effect","The way information is presented can influence how people interpret a choice.","PERSUASION"],
 ["Parasocial Interaction","A one-sided sense of connection with a media personality or public figure.","DIGITAL CULTURE"]
];
const investigations = [
 {id:"price-of-perception",title:"The Price of Perception",category:"THE BUYING MIND",dek:"Why does a higher price sometimes make a product feel better before we even try it?",read:"8 MIN READ"},
 {id:"influencer-effect",title:"The Influencer Effect",category:"THE INFLUENCE FACTOR",dek:"Would you buy something simply because your favourite influencer recommended it?",read:"10 MIN READ"},
 {id:"fomo-economy",title:"The FOMO Economy",category:"THE PSYCHOLOGY OF PERSUASION",dek:"How fear of missing out became a marketing strategy — and where persuasion becomes pressure.",read:"9 MIN READ"},
 {id:"endless-scroll",title:"The Endless Scroll",category:"THE DIGITAL CONSUMER",dek:"Why do digital platforms make it so easy to keep going and so difficult to stop?",read:"12 MIN READ"}
];
const app = document.getElementById("app");
const chapterList = document.getElementById("chapterList");
const conceptGrid = document.getElementById("conceptGrid");
const searchModal = document.getElementById("searchModal");
const searchInput = document.getElementById("searchInput");
const searchResults = document.getElementById("searchResults");

function renderHome(){
 chapterList.innerHTML = chapters.map(c=>`<a class="chapter-row" href="#chapter/${c.id}"><span class="chapter-number">${c.n}</span><h3>${c.title}</h3><p>${c.question}</p><span class="chapter-arrow">↗</span></a>`).join("");
 conceptGrid.innerHTML = concepts.slice(0,4).map(c=>`<article class="concept-card"><small>${c[2]}</small><h3>${c[0]}</h3><p>${c[1]}</p></article>`).join("");
}
function chapterPage(id){
 const c=chapters.find(x=>x.id===id); if(!c)return homeFallback();
 app.innerHTML=`<section class="reading-view"><a class="back-link" href="#chapters">← BACK TO CONTENTS</a><p class="section-kicker" style="margin-top:45px">CHAPTER ${c.n} / THE PUBLICATION</p><h1>${c.title}</h1><p class="dek">${c.question}</p><div class="reading-meta">THE MIND BEHIND THE CLICK · EDITED BY DHARSHINI T</div><div class="reading-body"><p>${c.desc}</p><h2>Inside this chapter</h2><p>This chapter is designed as a guided reading journey. Each topic introduces an idea, connects it to everyday experience and explores what it means for brands, platforms and consumers. The explanations below are a starting point for deeper investigations — not a substitute for evidence or a complete account of every debate.</p><div class="chapter-detail-grid">${c.topics.map((t,i)=>`<article class="topic-tile"><small class="section-kicker">${c.n}.${String(i+1).padStart(2,"0")}</small><h3>${t}</h3><p>${topicIntro(t,c.title)}</p><a href="#article/${topicSlug(t)}">OPEN TOPIC ↗</a></article>`).join("")}</div><div class="note" style="margin-top:35px"><strong>EDITORIAL NOTE</strong><br>As this publication grows, each topic will be expanded into a fully sourced article with research references, examples and clear methodology. Claims that require additional verification will not be presented as established facts.</div><h2>Continue exploring</h2><p>Move to another chapter to see the same question — human choice — from a different perspective.</p><div class="reading-actions"><a class="small-action" href="#chapters">← All chapters</a><a class="small-action" href="#library">Open research library →</a></div></div></section>`;
 window.scrollTo(0,0);
}
function topicIntro(topic,chapter){
 const intros={
 "Why We Buy What We Buy":"Purchases can reflect practical needs, emotional goals, social context and personal identity. The mix changes with the person and the situation.",
 "Emotional vs Rational Buying":"Consumers may compare features and prices while also responding to feelings, memories and expectations. These processes often work together.",
 "Impulse Buying Psychology":"An unplanned purchase can be shaped by mood, convenience, presentation, time pressure and the shopping environment.",
 "Price Perception":"Price is not only a payment; it can also become a cue people use to form expectations about quality, value or status.",
 "Social Proof":"When a choice feels uncertain, people may use other people's behaviour or opinions as one source of information.",
 "Influencer Marketing":"Creator recommendations combine product information with a relationship between the creator and their audience. Credibility and disclosure matter.",
 "Fear of Missing Out":"FOMO describes concern about missing rewarding experiences or opportunities. Marketers may invoke urgency, but the tactic raises ethical questions.",
 "The Attention Economy":"Digital services compete for limited human attention. Understanding that competition helps us ask who benefits from engagement."
 };
 return intros[topic] || `${topic} is one lens for examining ${chapter.toLowerCase()}. Explore its definition, everyday examples, evidence, limitations and implications for digital marketing.`;
}
function topicSlug(t){return t.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"")}
const articleContent = {
 "price-of-perception":{title:"The Price of Perception",category:"THE BUYING MIND",dek:"Why does a higher price sometimes make a product feel better before we even try it?",sections:[
 ["The number is never just a number","Imagine two products that appear almost identical. One is priced much higher. Before testing either product, a shopper may already expect the more expensive option to be better. That expectation is not proof of quality. It is a judgement formed from the signals available at the moment."],
 ["Price as a signal","When buyers cannot easily evaluate quality before purchase, price can become one cue among many. A premium price may suggest better materials, craftsmanship, service or exclusivity. But price is an imperfect signal: a high price does not guarantee high quality, and a low price does not automatically mean poor quality."],
 ["The role of perceived value","Perceived value is the consumer's overall assessment of what they receive compared with what they give up. That assessment can include performance, convenience, design, identity, service and emotional meaning — not just the amount paid."],
 ["What marketers do with this","Brands build a price story through positioning, packaging, product presentation, customer experience and comparisons. A premium strategy works only when the overall experience gives customers reasons to believe the promise. Otherwise, the gap between expectation and experience can damage trust."],
 ["The question consumers can ask","Instead of asking only whether a product is expensive or cheap, ask: What evidence supports the price? Which benefits matter to me? Am I paying for performance, convenience, identity, status or simply presentation?"]
 ],takeaway:"A price can shape expectations, but it cannot prove quality by itself."},
 "influencer-effect":{title:"The Influencer Effect",category:"THE INFLUENCE FACTOR",dek:"Would you buy something simply because your favourite creator recommended it?",sections:[
 ["A recommendation with a relationship","Influencer marketing is different from a traditional product announcement because audiences may feel familiar with the person making the recommendation. That familiarity can make a message feel personal, but it does not automatically make the recommendation accurate."],
 ["Trust is earned — and tested","Perceived expertise, honesty, consistency and clear disclosure can all matter when audiences evaluate a creator's recommendation. A sponsored post should be recognisable as advertising so people can judge the message with that context."],
 ["The social layer","Comments, reviews and audience reactions provide additional signals. These signals can help people discover products, but popularity is not the same as independent evidence of quality."],
 ["A more critical way to watch","Ask whether the creator has relevant experience, whether the commercial relationship is disclosed, whether the claims can be checked and whether the product fits your own needs."]
 ],takeaway:"Influence can start a purchase journey. It should not replace independent judgement."},
 "fomo-economy":{title:"The FOMO Economy",category:"THE PSYCHOLOGY OF PERSUASION",dek:"How fear of missing out can turn a message into a moment of pressure.",sections:[
 ["The feeling of being left out","Fear of missing out, commonly called FOMO, describes concern that others may be experiencing something rewarding while we are not. It can appear in social life, entertainment and shopping."],
 ["Urgency as a marketing device","Limited-time offers, countdowns and low-stock messages can make a decision feel time-sensitive. Sometimes the limitation is real; sometimes the presentation can exaggerate pressure. Consumers should be able to distinguish the two."],
 ["Persuasion or manipulation?","Persuasion presents reasons to choose. Manipulation hides relevant information, creates misleading pressure or makes it unnecessarily difficult to decline. Transparency and truthful availability claims are essential."],
 ["A pause is a powerful tool","Before responding to urgency, check the actual deadline, compare alternatives and ask whether you wanted the product before seeing the countdown."]
 ],takeaway:"A deadline can focus attention, but it should never replace truthful information."},
 "endless-scroll":{title:"The Endless Scroll",category:"THE DIGITAL CONSUMER",dek:"Why do digital platforms make it so easy to continue — and so difficult to stop?",sections:[
 ["A feed without a natural ending","Traditional pages and chapters provide stopping points. An infinite feed removes that obvious boundary, allowing new content to appear as a person continues scrolling."],
 ["Small design choices, repeated","Autoplay, recommendations, notifications and frictionless navigation can make continued use easier. Their effects vary across people and contexts, so no single feature explains every person's behaviour."],
 ["Attention is valuable","Many digital services rely on advertising, subscriptions or other models in which engagement can matter commercially. This creates an important question: how are platform incentives aligned with users' interests and wellbeing?"],
 ["Design and responsibility","A healthier digital experience can include clear controls, meaningful stopping cues, notification settings and transparent recommendation choices. Users also benefit from noticing their own patterns without blaming themselves."]
 ],takeaway:"The design of a feed can shape the experience of time. Understanding that design helps us make more deliberate choices."}
};
function articlePage(id){
 const a=articleContent[id]; if(!a){app.innerHTML=`<section class="reading-view"><a class="back-link" href="#home">← HOME</a><h1>Topic in development</h1><p class="dek">This topic is part of the publication's editorial roadmap.</p><p>It will be expanded into a researched article as sources and evidence are gathered.</p></section>`;return;}
 app.innerHTML=`<section class="reading-view"><a class="back-link" href="#investigations">← BACK TO INVESTIGATIONS</a><p class="section-kicker" style="margin-top:45px">INVESTIGATION / ${a.category}</p><h1>${a.title}</h1><p class="dek">${a.dek}</p><div class="reading-meta">BY DHARSHINI T · EDITORIAL EXPLAINER · ${a.sections.length+3} MIN READ</div><div class="reading-body"><p class="lead">The question behind this investigation is simple: what is happening beneath the visible choice?</p>${a.sections.map(s=>`<h2>${s[0]}</h2><p>${s[1]}</p>`).join("")}<blockquote>${a.takeaway}</blockquote><h2>What this means for digital marketing</h2><p>Marketers should use behavioural insights to make communication more useful, clear and relevant — not to bypass informed choice. Good strategy respects the audience's ability to understand an offer and say no.</p><h2>Methodology & sources</h2><div class="note">This page is an introductory editorial explainer, not a completed empirical investigation. It does not report original survey results or claim to represent a systematic literature review. Before publication as a fully researched investigation, add verified academic and primary sources, publication details, links, and any relevant limitations.</div><div class="reading-actions"><button class="small-action" id="bookmarkBtn" data-id="${id}">☆ Save to reading list</button><button class="small-action" id="shareBtn">↗ Share article</button><a class="small-action" href="#chapters">Explore chapters</a></div><p class="signature">FOUNDER & EDITOR <strong>DHARSHINI T</strong></p></div></section>`;
 document.getElementById("bookmarkBtn").addEventListener("click",()=>toggleBookmark(id));
 document.getElementById("shareBtn").addEventListener("click",shareCurrent);
 window.scrollTo(0,0);
}
function libraryPage(){
 app.innerHTML=`<section class="reading-view"><a class="back-link" href="#home">← HOME</a><p class="section-kicker" style="margin-top:45px">THE RESEARCH LIBRARY</p><h1>Understand the<br><em>language of influence.</em></h1><p class="dek">A growing glossary of psychology and marketing concepts, explained in accessible language.</p><div class="reading-meta">KNOWLEDGE INDEX · CURATED BY DHARSHINI T</div><div class="concept-grid">${concepts.map(c=>`<article class="concept-card"><small>${c[2]}</small><h3>${c[0]}</h3><p>${c[1]}</p></article>`).join("")}</div><div class="note" style="margin-top:30px">This is an introductory glossary. Each concept should be expanded with citations to foundational research and current reviews before being used as a formal academic reference.</div></section>`;
 window.scrollTo(0,0);
}
function aboutPage(){
 app.innerHTML=`<section class="reading-view"><a class="back-link" href="#home">← HOME</a><p class="section-kicker" style="margin-top:45px">THE PERSON BEHIND THE PUBLICATION</p><h1>Dharshini T<span style="color:var(--purple)">.</span></h1><p class="dek">Founder & Editor · The Mind Behind the Click</p><div class="reading-body"><h2>Why this publication exists</h2><p>I'm a final-year B.Com with Computer Applications student interested in journalism, consumer psychology and digital marketing. I wanted to create a space where these interests could meet through thoughtful questions and careful research.</p><p>We make choices every day: what to buy, whose advice to trust, what to watch and where to spend our attention. These choices are personal, but they also happen inside systems shaped by brands, platforms, design and culture.</p><p>The Mind Behind the Click is my independent learning and publishing project. It is a place to investigate those systems, explain useful ideas and remain curious about the people behind the data.</p><h2>Editorial promise</h2><p>I aim to make complex ideas understandable without making them simplistic. Research, interpretation and opinion should be clearly distinguished. When evidence is missing, that gap should be visible rather than hidden.</p><p class="signature">DHARSHINI T · FOUNDER & EDITOR</p></div></section>`;
 window.scrollTo(0,0);
}
function homeFallback(){location.hash="#home";}
function route(){
 const hash=decodeURIComponent(location.hash.slice(1)||"home");
 if(hash==="home"||hash==="publication"||hash==="chapters"||hash==="investigations"||hash==="about"){document.querySelectorAll("main section").forEach(s=>s.style.display="");if(hash==="about")aboutPage();else if(hash==="investigations")document.getElementById("investigations").scrollIntoView();else if(hash==="chapters")document.getElementById("chapters").scrollIntoView();else if(hash==="publication")document.getElementById("publication").scrollIntoView();else {location.hash="";window.scrollTo(0,0);}return;}
 if(hash==="library"){libraryPage();return;}
 if(hash.startsWith("chapter/")){chapterPage(hash.split("/")[1]);return;}
 if(hash.startsWith("article/")){articlePage(hash.split("/")[1]);return;}
}
function toggleBookmark(id){
 let saved=JSON.parse(localStorage.getItem("tmbtc-bookmarks")||"[]");
 saved=saved.includes(id)?saved.filter(x=>x!==id):[...saved,id];
 localStorage.setItem("tmbtc-bookmarks",JSON.stringify(saved));
 const b=document.getElementById("bookmarkBtn"); if(b)b.textContent=saved.includes(id)?"★ Saved to reading list":"☆ Save to reading list";
 toast(saved.includes(id)?"Saved to your reading list":"Removed from your reading list");
}
function shareCurrent(){if(navigator.share){navigator.share({title:document.title,url:location.href}).catch(()=>{});}else{navigator.clipboard?.writeText(location.href);toast("Article link copied (if clipboard permission is available)");}}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200);}
function openSearch(){searchModal.classList.add("open");searchModal.setAttribute("aria-hidden","false");searchInput.focus();}
function closeSearch(){searchModal.classList.remove("open");searchModal.setAttribute("aria-hidden","true");}
function runSearch(q){
 const term=q.trim().toLowerCase(); if(!term){searchResults.innerHTML='<p class="muted">Search chapters, investigations and psychology concepts.</p>';return;}
 const results=[];
 chapters.forEach(c=>{if((c.title+" "+c.question+" "+c.topics.join(" ")).toLowerCase().includes(term))results.push({label:c.title,detail:"CHAPTER",href:"#chapter/"+c.id});});
 investigations.forEach(a=>{if((a.title+" "+a.dek+" "+a.category).toLowerCase().includes(term))results.push({label:a.title,detail:a.category,href:"#article/"+a.id});});
 concepts.forEach(c=>{if((c[0]+" "+c[1]+" "+c[2]).toLowerCase().includes(term))results.push({label:c[0],detail:"RESEARCH LIBRARY",href:"#library"});});
 searchResults.innerHTML=results.length?results.map(r=>`<a href="${r.href}" class="result-link"><small>${r.detail}</small>${r.label} ↗</a>`).join(""):'<p class="muted">No results yet. Try another keyword.</p>';
 searchResults.querySelectorAll("a").forEach(a=>a.addEventListener("click",closeSearch));
}
document.getElementById("searchOpen").addEventListener("click",openSearch);
document.getElementById("searchClose").addEventListener("click",closeSearch);
searchModal.addEventListener("click",e=>{if(e.target===searchModal)closeSearch();});
searchInput.addEventListener("input",e=>runSearch(e.target.value));
document.getElementById("menuToggle").addEventListener("click",()=>{const nav=document.getElementById("mainNav");const open=nav.classList.toggle("open");document.getElementById("menuToggle").setAttribute("aria-expanded",String(open));});
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("open")));
window.addEventListener("hashchange",route);
document.getElementById("year").textContent=new Date().getFullYear();
renderHome();
route();
